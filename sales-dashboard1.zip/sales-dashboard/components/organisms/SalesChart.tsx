"use client";

import { useState } from "react";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

import { salesData } from "../../data/salesData";

export default function SalesChart() {
  const [chartType, setChartType] = useState<"bar" | "line" | "pie">("bar");

  return (
    <div className="w-full border border-gray-300 p-4">
      
      {/* Buttons */}
      <div className="flex gap-4 mb-4">
        <button
          onClick={() => setChartType("bar")}
          className="px-4 py-2 bg-blue-600 text-white rounded"
        >
          Bar
        </button>
        <button
          onClick={() => setChartType("line")}
          className="px-4 py-2 bg-green-600 text-white rounded"
        >
          Line
        </button>
        <button
          onClick={() => setChartType("pie")}
          className="px-4 py-2 bg-orange-600 text-white rounded"
        >
          Pie
        </button>
      </div>

      {/* Chart container MUST have fixed height */}
      <div className="w-full h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          {chartType === "bar" && (
            <BarChart data={salesData}>
              <XAxis dataKey="year" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="sales" fill="#2563eb" />
            </BarChart>
          )}

          {chartType === "line" && (
            <LineChart data={salesData}>
              <XAxis dataKey="year" />
              <YAxis />
              <Tooltip />
              <Line
                dataKey="sales"
                stroke="#16a34a"
                strokeWidth={3}
              />
            </LineChart>
          )}

          {chartType === "pie" && (
            <PieChart>
              <Pie
                data={salesData}
                dataKey="sales"
                nameKey="year"
                cx="50%"
                cy="50%"
                outerRadius={100}
                label
              />
              <Tooltip />
            </PieChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
}
