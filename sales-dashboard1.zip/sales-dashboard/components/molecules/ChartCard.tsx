import SalesChart from "../organisms/SalesChart";

export default function ChartCard() {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h2 className="text-xl font-semibold mb-4">
        Sales Report (2022 – 2024)
      </h2>
      <SalesChart />
    </div>
  );
}
