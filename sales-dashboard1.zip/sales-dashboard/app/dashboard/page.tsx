"use client";

import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";
import { useState } from "react";

export default function DashboardPage() {
  const [type, setType] = useState<"bar" | "line" | "pie">("bar");

  const data = [
    { year: "2022", sales: 12000 },
    { year: "2023", sales: 18000 },
    { year: "2024", sales: 25000 },
  ];

  return (
    <div style={{ padding: 40 }}>
      <h1 style={{ fontSize: 28, fontWeight: "bold" }}>
        Sales Dashboard
      </h1>

      <p>Sales Report (2022 – 2024)</p>

      {/* Buttons */}
      <div style={{ margin: "20px 0" }}>
        <button onClick={() => setType("bar")}>Bar</button>{" "}
        <button onClick={() => setType("line")}>Line</button>{" "}
        <button onClick={() => setType("pie")}>Pie</button>
      </div>

      {/* Charts */}
      {type === "bar" && (
        <BarChart width={500} height={300} data={data}>
          <XAxis dataKey="year" />
          <YAxis />
          <Tooltip />
          <Bar dataKey="sales" fill="#2563eb" />
        </BarChart>
      )}

      {type === "line" && (
        <LineChart width={500} height={300} data={data}>
          <XAxis dataKey="year" />
          <YAxis />
          <Tooltip />
          <Line dataKey="sales" stroke="#16a34a" strokeWidth={3} />
        </LineChart>
      )}

      {type === "pie" && (
        <PieChart width={500} height={300}>
          <Pie
            data={data}
            dataKey="sales"
            nameKey="year"
            cx="50%"
            cy="50%"
            outerRadius={100}
            label
          />
          <Tooltip />
        </PieChart>
      )}
    </div>
  );
}
