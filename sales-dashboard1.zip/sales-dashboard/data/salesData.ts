export const salesData = [
  { year: "2022", sales: 12000 },
  { year: "2023", sales: 18000 },
  { year: "2024", sales: 25000 },
];
